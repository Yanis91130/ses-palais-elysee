
const breakdown = [
  ['Acquisition foncière (sites ultra-centrés)',4500000000],
  ['Construction structure & finitions (100k m², haut standing)',3200000000],
  ['Bunker, datacenter souverain & cybersécurité',1000000000],
  ['Sécurité permanente & infrastructures militaires',1000000000],
  ['Démolition, dépollution, fouilles archéologiques',600000000],
  ['Musées, auditoriums & aménagements protocolaire',700000000],
  ['Transports & accès dédiés (station privée, parkings, héliport)',600000000],
  ['Relogement provisoire du Président & bureaux temporaires',300000000],
  ['Continuité d\'État (site redondant)',300000000],
  ['Juridique / expropriations / indemnités / communication',800000000],
  ['Réserve & inflation (incl. imprévus)',1300000000],
  ['Divers & aménagements urbains connexes',600000000]
];

function formatEUR(n){ return n.toLocaleString('fr-FR') + ' €'; }

function populateBudgetTable(){
  const tbody = document.querySelector('#bigBudget tbody');
  if(!tbody) return;
  let total = 0;
  breakdown.forEach(([name, amount])=>{
    const tr = document.createElement('tr');
    const td1 = document.createElement('td'); td1.textContent = name;
    const td2 = document.createElement('td'); td2.textContent = formatEUR(amount);
    tr.appendChild(td1); tr.appendChild(td2);
    tbody.appendChild(tr);
    total += amount;
  });
  document.querySelector('#bigBudget tfoot td:last-child').textContent = formatEUR(total);
}

document.addEventListener('DOMContentLoaded', ()=>{
  populateBudgetTable();
  const dl = document.getElementById('csvDownload');
  if(dl) dl.addEventListener('click', ()=>{
    const rows = [['Poste','Montant']];
    breakdown.forEach(b=> rows.push([b[0], b[1]]));
    rows.push(['Total', breakdown.reduce((s,b)=>s+b[1],0)]);
    const csv = rows.map(r=> r.map(c=> '"'+String(c).replace(/"/g,'""')+'"').join(',')).join('\n');
    const blob = new Blob([csv], {type:'text/csv;charset=utf-8;'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'budget_palais_elysee_colossal.csv'; a.click();
    URL.revokeObjectURL(url);
  });
});
